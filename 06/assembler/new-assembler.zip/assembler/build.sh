 #!/usr/bin/bash 
g++ -std=c++20 -g parser.cc main.cc
